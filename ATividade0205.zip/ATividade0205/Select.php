<?php require "header.php"?>
<?php
require "Fabricadeconexao.php";


$comando ="SELECT * FROM endereco";
$resultado=mysqli_query($conexao,$comando);



while($dados = mysqli_fetch_assoc($resultado)){
  echo "\n";
  echo $dados["rua"];
  echo $dados["numerio"];
  echo $dados["complemento"];
  echo $dados["bairro"];
  echo $dados["cep"];
  echo $dados["cidade"];
  echo $dados["estado"];
  echo $dados["pais"];
  echo "\n";
}

 require "footer.php";

 