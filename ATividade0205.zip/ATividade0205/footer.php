<footer>
  este eh o rodape adsdas
</footer>

</body>
</html>