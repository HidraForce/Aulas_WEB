<?php
require "conexao.php";

$comando ="SELECT * FROM dados_dos_enderecos";
$resultado=mysqli_query($conexao,$comando);
?>
<div class="tabela">
  <h1>Dados da Tabela</h1>
  <table class="info">
    <?php while($dados = mysqli_fetch_assoc($resultado)): ?>
    <tr>
      <th>Posição</th>
      <th>Rua</th>
      <th>Exibir</th>
      <th>Deletar</th>
    </tr>
    <tr>
      <th><?= $dados["idEndereco"]; ?></th>
      <th><?= $dados["nome_Rua"]; ?></th>     
      <th><a href="selectOne.php?id=<?= $dados["idEndereco"]?>">exibir</a></th>
      <th><a href="delete_new.php?id=<?= $dados["idEndereco"]?>">Deletar</a></th>  
    </tr>  

    <?php endwhile ?> 
    </table>

</div>