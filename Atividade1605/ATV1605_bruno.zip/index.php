<!DOCTYPE html>
<html lang="PT-BR">
<head>
  <link rel="stylesheet" href="new.css">
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>NOVO ENDEREÇO</title>
</head>
<body>
  <form action="insert.php" method="post">
    <input type="text" name="rua" placeholder="INSIRA O NOME DA RUA" class="form_item"><br>
    <input type="number" name="num" placeholder="INSIRA O NUMERO DO IMOVEL" class="form_item"><br>
    <input type="text" name="bairro" placeholder="INSIRA O NOME DO BAIRRO" class="form_item"><br>
    <button>Terminar</button>
  </form>
  <a href="select_new.php">Mostrar endereços</a>
</body>
</html>