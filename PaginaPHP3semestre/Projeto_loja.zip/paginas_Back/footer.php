<div class="item5">
            <!-- TABELA PARA MOSTRAR E ORGANIZAR O RODAPÉ -->
           <table id="tbi5">
               <tr class="trRodapé">
                   <th class="thRodapé"><a href="Sobre.php">SObre nós</a></th>
                   <th class="thRodapé"><a href="#">Nossas parceiras</a></th>
                   <th class="thRodapé"><a href="#">Venda seus livros aqui</a></th>
               </tr>
               <tr class="trRodapé">
                   <th class="thRodapé"><a href="#">Twitter</a></th>
                   <th class="thRodapé"><a href="#">Insta</a></th>
                   <th class="thRodapé"><a href="#">Facebook</a></th>
               </tr>
               <tr class="trRodapé">
                   <th class="thRodapé"><a href="#">Trabelhe conocoso</a></th>
                   <th class="thRodapé"><a href="#">Nossa equipe</a></th>
                   <th class="thRodapé"><a href="#">Avaliações</a></th>
               </tr>
           </table>
        <!-- ---------------------------------------------------------------------------------------------------------- -->
        
        
       <!-- RODEPÉ INUTIL POREM ATRATIVO COM UMA FRASE QUE REPRESENTE OS IDEAIS DA EMPRESA ----------------------------- -->
       <div class="item6">
            <h1>Ler é pra todos , ler é cultura,  ninguém sabe</h1>

        </div>
        <!-- ---------------------------------------------------------------------------------------------------------- -->
    </div>
    <!-- ----------------------------------------------------------------------------------------------------------FIM DA PAGINA -->
</body>

</html>

